"""Originalprüfung wie Python __main__ ausführen; Fehler vor FreeCADs Wiederholung beenden.

Das eigene regulär importierte Mod/Init.py auditiert Profil und Quelle davor. Dieser
Einstieg ersetzt keine FreeCAD-Funktion und verändert keine Originalprüfdatei.
"""

import json
import os
import runpy
import sys
import traceback
from pathlib import Path


def pruefung_ausfuehren():
    """Erfordert den vorangegangenen Profilnachweis und erhält normale Python-Mainguards."""
    profil = Path(os.environ["CAMADDON_ABGABE_ERWARTETES_PROFIL"]).resolve()
    quelle = Path(os.environ["CAMADDON_ABGABE_QUELLE"]).resolve()
    test = Path(os.environ["CAMADDON_TESTDATEI"]).resolve()
    audit = json.loads((profil / "profilpruefung.json").read_text(encoding="utf-8"))
    assert audit["profil"] == str(profil), "Testprofil wurde nicht vorab auditiert"
    assert audit["quelle"] == str(quelle), "Geprüfte Addon-Quelle stimmt nicht überein"
    assert audit["test"] == str(test), "Vorab geprüft wurde eine andere Prüfdatei"
    assert audit["audit_modul"] == "abgabe_native", "Regulärer Native-Mod-Einstieg fehlt"
    assert test.is_file() and test.parent == quelle / "tests", "Ungültiger Originaltestpfad"
    runpy.run_path(str(test), run_name="__main__")


try:
    pruefung_ausfuehren()
except BaseException as fehler:
    if not isinstance(fehler, SystemExit) or fehler.code not in (None, 0):
        traceback.print_exc(file=sys.stderr)
        sys.stdout.flush()
        sys.stderr.flush()
        # FreeCAD kann eine gescheiterte Skriptdatei anschließend als __main__
        # importieren. Nur unseren eigenen Prüfprozess vor dieser Wiederholung beenden.
        os._exit(2)
