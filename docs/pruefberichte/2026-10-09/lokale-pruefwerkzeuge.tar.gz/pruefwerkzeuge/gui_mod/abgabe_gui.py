"""Eigenes sichtbares Prüfharness: Profilassert, Szenarioschritte und Qt-Fenster auf DP-1.

FreeCAD- und Addon-Dateien bleiben unverändert. Nur das eigene Test-Modul installiert
einen öffentlichen Qt-Eventfilter zur Platzierung und richtet drei alte Bildschirm-
Screenshot-Helfer auf dieselbe Anzeige. Fachliche Szenarioschritte und Assertions
werden aus der eingefrorenen Originaldatei ausgeführt.
"""

import importlib.util
import json
import os
import sys
import traceback
from pathlib import Path

import FreeCAD as App
import FreeCADGui as Gui
from PySide import QtCore, QtGui

_referenzen = []


class Bildschirmwache(QtCore.QObject):
    """Platziert nur sichtbare eigene Top-Level-Fenster über die öffentliche Qt-API."""

    def __init__(self, main, screen, out):
        super().__init__(main)
        self.main, self.screenname, self.out = main, screen.name(), out
        self._setzt = False
        self._gesehen = set()
        self.fenster = []
        self.timer = QtCore.QTimer(self)
        self.timer.timeout.connect(self.pruefen)
        self.timer.start(200)

    @property
    def screen(self):
        # FreeCAD erneuert QScreen-Objekte während des Starts. Nur den Namen
        # behalten und die aktuelle Qt-Instanz bei jeder Verwendung neu lesen.
        return next(s for s in QtGui.QApplication.screens() if s.name() == self.screenname)

    def eventFilter(self, obj, event):
        if event.type() in (QtCore.QEvent.Show, QtCore.QEvent.Move) and not self._setzt:
            if isinstance(obj, QtGui.QWidget) and obj.isWindow():
                self.platzieren(obj)
        return False

    def platzieren(self, widget):
        """Der Besitzer bleibt erhalten; nur Bildschirm und Lage werden geändert."""
        if self._setzt or not widget.isVisible():
            return
        self._setzt = True
        try:
            screen = self.screen
            bereich = screen.availableGeometry()
            handle = widget.windowHandle()
            if handle is not None and (
                handle.screen() is None or handle.screen().name() != self.screenname
            ):
                handle.setScreen(screen)
            if not bereich.contains(widget.frameGeometry().center()):
                widget.move(bereich.center() - widget.rect().center())
            if id(widget) not in self._gesehen:
                self._gesehen.add(id(widget))
                self.fenster.append(
                    {
                        "klasse": widget.metaObject().className(),
                        "titel": widget.windowTitle(),
                        "modal": widget.isModal(),
                        "besitzer": (
                            widget.parentWidget().windowTitle() if widget.parentWidget() else None
                        ),
                    }
                )
        finally:
            self._setzt = False

    def pruefen(self):
        for widget in QtGui.QApplication.topLevelWidgets():
            self.platzieren(widget)
        frame = self.main.frameGeometry()
        sichtbare = []
        for w in QtGui.QApplication.topLevelWidgets():
            if not w.isVisible():
                continue
            g = w.frameGeometry()
            sichtbare.append(
                {
                    "klasse": w.metaObject().className(),
                    "titel": w.windowTitle(),
                    "modal": w.isModal(),
                    "auf_bildschirm": self.screen.geometry().contains(g.center()),
                    "rahmen": [g.x(), g.y(), g.width(), g.height()],
                }
            )
        (self.out / "bildschirm.json").write_text(
            json.dumps(
                {
                    "bildschirm": self.screen.name(),
                    "hauptfenster_auf_bildschirm": self.screen.geometry().contains(frame.center()),
                    "hauptfenster": [frame.x(), frame.y(), frame.width(), frame.height()],
                    "sichtbare_fenster": sichtbare,
                    "gesehene_fenster": self.fenster,
                },
                ensure_ascii=False,
                indent=2,
            ),
            encoding="utf-8",
        )


class UndoBeobachter:
    """Beobachtet die öffentliche Undo-Schnittstelle ausschließlich im eigenen GUI-Testprofil."""

    def __init__(self):
        self.ereignisse = []

    def merke(self, art, dokument, objekt=""):
        try:
            self.ereignisse.append({
                "art": art,
                "dokument": dokument.Name if dokument is not None else None,
                "objekt": objekt,
                "transaktion": App.getActiveTransaction(),
                "undo": list(dokument.UndoNames) if dokument is not None else [],
            })
        except Exception as fehler:
            self.ereignisse.append({"art": art, "objekt": objekt, "diagnosefehler": str(fehler)})

    def slotOpenTransaction(self, dokument, name):
        self.merke("open", dokument, name)

    def slotCommitTransaction(self, dokument):
        self.merke("commit", dokument)

    def slotCreatedObject(self, objekt):
        self.merke("create", objekt.Document, objekt.Name)

    def slotDeletedObject(self, objekt):
        self.merke("delete", objekt.Document, objekt.Name)

    def slotUndoDocument(self, dokument):
        self.merke("undo", dokument)


def starten():
    """Szenario erst nach Profil- und Quellenprüfung laden; Benutzerprofile bleiben unberührt."""
    out = Path(os.environ["CAMADDON_AUSGABE"]).resolve()
    try:
        profil = Path(os.environ["FREECAD_USER_HOME"]).resolve()
        quelle = Path(os.environ["CAMADDON_ABGABE_QUELLE"]).resolve()
        szenario = Path(os.environ["CAMADDON_SZENARIO"]).resolve()
        assert profil.is_dir() and Path(App.getUserAppDataDir()).resolve() == profil
        assert szenario.parent == quelle / "tests/gui"
        sys.path.insert(0, str(quelle))
        import camaddon

        assert Path(camaddon.ADDON_ORDNER).resolve() == quelle
        (profil / "profilpruefung.json").write_text(
            json.dumps(
                {
                    "profil": str(profil),
                    "quelle": str(quelle),
                    "addon": camaddon.VERSION,
                    "freecad": ".".join(App.Version()[:3]),
                    "szenario": str(szenario),
                },
                indent=2,
            ),
            encoding="utf-8",
        )
        screenname = os.environ.get("CAMADDON_BILDSCHIRM", "DP-1")
        screen = next((s for s in QtGui.QApplication.screens() if s.name() == screenname), None)
        assert screen is not None, f"Gewünschter zweiter Bildschirm {screenname} fehlt"
        main = Gui.getMainWindow()
        main.showNormal()
        main.windowHandle().setScreen(screen)
        main.setGeometry(screen.availableGeometry())
        main.showMaximized()
        wache = Bildschirmwache(main, screen, out)
        QtGui.QApplication.instance().installEventFilter(wache)
        _referenzen.append(wache)
        sys.path.insert(0, str(quelle / "tests/gui/_lauf"))
        import szenario_lauf as lauf

        spec = importlib.util.spec_from_file_location("abgabe_original_szenario", szenario)
        modul = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(modul)
        umleitung = szenario.name in (
            "szenario_werkzeugverwaltung.py",
            "szenario_halter_richtung.py",
            "szenario_schnittwerte.py",
        )
        if umleitung:

            def bildschirm(name):
                QtGui.QApplication.processEvents()
                wache.pruefen()
                wache.screen.grabWindow(0).save(str(out / f"{name}.png"))

            modul.bildschirm = bildschirm
        (out / "instrumentierung.json").write_text(
            json.dumps(
                {
                    "original_szenario": str(szenario),
                    "screenshot_helfer_auf_dp1": umleitung,
                    "qt_api": "QObject.eventFilter, QWindow.setScreen, QWidget.move, QScreen.grabWindow",
                    "freecad_addon_dateien_unveraendert": True,
                },
                ensure_ascii=False,
                indent=2,
            ),
            encoding="utf-8",
        )
        helfer = lauf.Helfer()
        ablauf = modul.schritte(helfer)
        undo_beobachter = None
        if szenario.name == "szenario_werkzeugzugang.py":
            undo_beobachter = UndoBeobachter()
            App.addDocumentObserver(undo_beobachter)
            _referenzen.append(undo_beobachter)
        import faulthandler

        absturz = (out / "absturz.txt").open("w")
        _referenzen.append(absturz)
        faulthandler.enable(absturz)
        vorher = sys.excepthook

        def ausnahme(art, wert, verlauf):
            text = "".join(traceback.format_exception(art, wert, verlauf))
            helfer.fehler.append("Ausnahme in der Oberfläche:\n" + text)
            vorher(art, wert, verlauf)

        sys.excepthook = ausnahme

        def ende(fehler=None):
            if undo_beobachter is not None:
                App.removeDocumentObserver(undo_beobachter)
                (out / "undo-transaktionen.json").write_text(
                    json.dumps(undo_beobachter.ereignisse, ensure_ascii=False, indent=2),
                    encoding="utf-8",
                )
            wache.timer.stop()
            QtGui.QApplication.instance().removeEventFilter(wache)
            wache.pruefen()
            main.grab().save(str(out / "bildschirm-ende.png"))
            lauf._ende(helfer, fehler)

        def weiter():
            try:
                warten = next(ablauf)
            except StopIteration:
                ende()
                return
            except Exception:
                ende(traceback.format_exc())
                return
            QtCore.QTimer.singleShot(int(warten), weiter)

        def vorbereitungsbild():
            wache.pruefen()
            main.grab().save(str(out / "bildschirm-start.png"))

        QtCore.QTimer.singleShot(1200, vorbereitungsbild)
        QtCore.QTimer.singleShot(lauf.START_NACH_MS, weiter)
        App.Console.PrintMessage(f"PROFIL_GEPRUEFT {profil}\nSzenario geladen: {szenario}\n")
    except Exception:
        text = traceback.format_exc()
        (out / "ergebnis.txt").write_text(text, encoding="utf-8")
        App.Console.PrintError(text)
        QtCore.QTimer.singleShot(1000, QtGui.QApplication.quit)
