# Ausschließlich im isolierten Gesamtlauf-Testprofil geladen.
import abgabe_gui

abgabe_gui.starten()
