#!/usr/bin/env bash
# Gesamter eingefrorener Stand im installierten FreeCAD; läuft erst auf ausdrücklichen Start.
# Aufruf: systemd-run --user --scope -q -p MemoryMax=16G -p MemorySwapMax=0 bash gesamtlauf.sh
set -uo pipefail
camaddon_runner="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
camaddon_quelle="${CAMADDON_GESAMTQUELLE:-/home/manuel/freecad_cam/testen/0.204.0/addon}"
camaddon_stamp="$(date +%Y%m%d-%H%M%S)"
camaddon_ausgabe="${CAMADDON_GESAMTAUSGABE:-$camaddon_runner/gesamtlauf-$camaddon_stamp}"
camaddon_native_limit="${CAMADDON_NATIVE_TIMEOUT:-900}"
camaddon_native_lang_limit="${CAMADDON_NATIVE_LANG_TIMEOUT:-2400}"
camaddon_gui_limit="${CAMADDON_GUI_TIMEOUT:-180}"
camaddon_py="${CAMADDON_SYSTEMPYTHON:-/usr/bin/python3}"
if [[ ! -f "$camaddon_quelle/package.xml" || ! -x /usr/bin/freecadcmd || ! -x /usr/bin/freecad ]]; then
    echo 'FEHLER: eingefrorene Addon-Quelle oder installiertes FreeCAD fehlt.' >&2
    exit 2
fi
if [[ -e "$camaddon_ausgabe/ergebnisse.tsv" ]]; then
    echo 'FEHLER: Ausgabe enthält schon einen Lauf; neues Ausgabeverzeichnis wählen.' >&2
    exit 2
fi
mkdir -p "$camaddon_ausgabe/native" "$camaddon_ausgabe/gui" "$camaddon_ausgabe/profile"
export LC_ALL=C.UTF-8 CAMADDON_OHNE_UPDATE=1 OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1
# Referenzen bleiben unverändert; Speicherbudget der Simultanqualität wird tatsächlich geprüft.
unset BESTMARKEN_SCHREIBEN GOLDENE_BAHNEN_SCHREIBEN RAUM_GOLDEN_SCHREIBEN FOLGE_GOLDEN_SCHREIBEN
unset SIMULTAN_BEISPIEL_SCHREIBEN SIMULTAN_TEST_DOKUMENT SIMULTAN_NC_DOKUMENT SIMULTAN_TEST_ANSTELLUNG
unset CAMADDON_NATIVE_DIAGNOSE
export SIMULTAN_SPEICHER_MESSEN=1
export CAMADDON_BILDSCHIRM="${CAMADDON_BILDSCHIRM:-DP-1}"
export CAMADDON_GROB_BILDSCHIRM="$CAMADDON_BILDSCHIRM"
export CAMADDON_ABGABE_QUELLE="$camaddon_quelle"
"$camaddon_py" "$camaddon_runner/gesamtlauf_hilfe.py" inventar "$camaddon_quelle" "$camaddon_ausgabe" \
    || exit 2
printf 'art\tname\tstatus\texit\tsekunden\tmaxrss_mib\tbeleg\n' > "$camaddon_ausgabe/ergebnisse.tsv"
camaddon_fehler=0

camaddon_zeile() {
    local art="$1" name="$2" status="$3" exitcode="$4" start="$5" log="$6" messung="${7:-}"
    local sekunden rss
    sekunden="$("$camaddon_py" "$camaddon_runner/gesamtlauf_hilfe.py" dauer "$start")"
    rss="$("$camaddon_py" "$camaddon_runner/gesamtlauf_hilfe.py" rss "$messung")"
    printf '%s\t%s\t%s\t%s\t%s\t%s\t%s\n' "$art" "$name" "$status" "$exitcode" "$sekunden" "$rss" "$log" \
        >> "$camaddon_ausgabe/ergebnisse.tsv"
    printf '%-10s %-9s %-46s %8s s\n' "$status" "$art" "$name" "$sekunden"
}

while IFS= read -r camaddon_test; do
    camaddon_name="$(basename -- "$camaddon_test")"
    camaddon_start="$("$camaddon_py" "$camaddon_runner/gesamtlauf_hilfe.py" jetzt)"
    camaddon_log="$camaddon_ausgabe/native/${camaddon_name%.py}.log"
    if "$camaddon_py" "$camaddon_runner/gesamtlauf_hilfe.py" vorgeprueft \
        "$camaddon_runner/native_vorbelege.json" "$camaddon_quelle" "$camaddon_test" "$camaddon_log"; then
        camaddon_zeile native "$camaddon_name" VORGEPRUEFT 0 "$camaddon_start" "$camaddon_log"
        continue
    fi
    camaddon_profil="$camaddon_ausgabe/profile/native-${camaddon_name%.py}"
    camaddon_messung="$camaddon_ausgabe/native/${camaddon_name%.py}.prozess.json"
    camaddon_limit="$camaddon_native_limit"
    case "$camaddon_name" in
        test_simultan_planung.py|test_simultan_nc.py|test_simultan_folge.py|*gesamt*.py|*lang*.py)
            camaddon_limit="$camaddon_native_lang_limit" ;;
    esac
    mkdir -p "$camaddon_profil/Mod" "$camaddon_ausgabe/native/${camaddon_name%.py}"
    ln -s "$camaddon_quelle" "$camaddon_profil/Mod/freecad-cam-addon"
    ln -s "$camaddon_runner/native_mod" "$camaddon_profil/Mod/_camaddon_abgabe_native"
    env QT_QPA_PLATFORM=offscreen FREECAD_USER_HOME="$camaddon_profil" \
        CAMADDON_ABGABE_ERWARTETES_PROFIL="$camaddon_profil" \
        CAMADDON_TESTDATEI="$camaddon_test" \
        CAMADDON_PRUEFAUSGABE="$camaddon_ausgabe/native/${camaddon_name%.py}" \
        "$camaddon_py" "$camaddon_runner/gesamtlauf_hilfe.py" ausfuehren "$camaddon_messung" \
        timeout --kill-after=15 "$camaddon_limit" \
        /usr/bin/freecadcmd -u "$camaddon_profil/user.cfg" -s "$camaddon_profil/system.cfg" \
        "$camaddon_runner/nativeEntry.py" > "$camaddon_log" 2>&1
    camaddon_exit=$?
    camaddon_status="$("$camaddon_py" "$camaddon_runner/gesamtlauf_hilfe.py" pruefe-native \
        "$camaddon_log" "$camaddon_name" "$camaddon_exit" "$camaddon_profil")"
    if [[ "$camaddon_status" == FEHLER ]]; then camaddon_fehler=1; fi
    camaddon_zeile native "$camaddon_name" "$camaddon_status" "$camaddon_exit" "$camaddon_start" "$camaddon_log" "$camaddon_messung"
done < "$camaddon_ausgabe/native-liste.txt"

while IFS= read -r camaddon_szenario; do
    camaddon_name="$(basename -- "$camaddon_szenario" .py)"
    camaddon_start="$("$camaddon_py" "$camaddon_runner/gesamtlauf_hilfe.py" jetzt)"
    camaddon_ziel="$camaddon_ausgabe/gui/$camaddon_name"
    camaddon_profil="$camaddon_ausgabe/profile/gui-$camaddon_name"
    mkdir -p "$camaddon_ziel" "$camaddon_profil/Mod"
    ln -s "$camaddon_quelle" "$camaddon_profil/Mod/freecad-cam-addon"
    ln -s "$camaddon_runner/gui_mod" "$camaddon_profil/Mod/_camaddon_abgabe_lauf"
    camaddon_log="$camaddon_ziel/freecad.log"
    camaddon_messung="$camaddon_ziel/prozess.json"
    env QT_QPA_PLATFORM=xcb FREECAD_USER_HOME="$camaddon_profil" \
        CAMADDON_SZENARIO="$camaddon_szenario" CAMADDON_AUSGABE="$camaddon_ziel" \
        "$camaddon_py" "$camaddon_runner/gesamtlauf_hilfe.py" ausfuehren "$camaddon_messung" \
        timeout --kill-after=15 "$camaddon_gui_limit" \
        /usr/bin/freecad -u "$camaddon_profil/user.cfg" -s "$camaddon_profil/system.cfg" \
        > "$camaddon_log" 2>&1
    camaddon_exit=$?
    camaddon_status="$("$camaddon_py" "$camaddon_runner/gesamtlauf_hilfe.py" pruefe-gui \
        "$camaddon_ziel" "$camaddon_exit" "$camaddon_profil" "$CAMADDON_BILDSCHIRM")"
    if [[ "$camaddon_status" != OK ]]; then camaddon_fehler=1; fi
    camaddon_zeile gui "$camaddon_name" "$camaddon_status" "$camaddon_exit" "$camaddon_start" "$camaddon_log" "$camaddon_messung"
done < "$camaddon_ausgabe/gui-liste.txt"

"$camaddon_py" "$camaddon_runner/gesamtlauf_hilfe.py" zusammenfassung "$camaddon_ausgabe" \
    || camaddon_fehler=1
echo "Belege: $camaddon_ausgabe"
exit "$camaddon_fehler"
