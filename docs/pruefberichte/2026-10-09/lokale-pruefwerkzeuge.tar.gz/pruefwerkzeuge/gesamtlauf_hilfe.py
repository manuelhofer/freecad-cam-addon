"""Manifest, strenge Logwertung und Zusammenfassung ohne eigene FreeCAD-Prozesse."""

import csv
import hashlib
import json
import re
import shutil
import subprocess
import sys
import time
from collections import Counter
from pathlib import Path


def kernkennung(quelle):
    """Rechen-/UI-Code samt festen Prüfdaten; reine Dokumentation verändert keinen Vorbeleg."""
    files = sorted(
        p
        for name in ("camaddon", "daten", "translations", "beispiele", "tests")
        for p in (quelle / name).rglob("*")
        if p.is_file() and "__pycache__" not in p.parts and p.suffix != ".pyc"
    )
    files.extend(sorted(quelle.glob("Init*.py")))
    h = hashlib.sha256()
    for p in files:
        h.update(str(p.relative_to(quelle)).encode("utf-8") + b"\0")
        h.update(p.read_bytes())
        h.update(b"\0")
    return h.hexdigest()


def logfehler(text):
    """FreeCAD darf eine Python-Ausnahme trotz Exitcode 0 niemals als bestanden werten."""
    return bool(
        re.search(
            r"Traceback|Exception while processing file:|Segmentation fault|Fatal Python error",
            text,
        )
    )


def exakt_ok(text, name):
    return bool(re.search(r"(?:^|\s)OK " + re.escape(name) + r"\s*$", text, re.MULTILINE))


def inventar(quelle, ausgabe):
    native = sorted(quelle.glob("tests/test_*.py"))
    gui = sorted(quelle.glob("tests/gui/szenario_*.py"))
    assert native and gui
    for name, files in (("native", native), ("gui", gui)):
        (ausgabe / f"{name}-liste.txt").write_text(
            "".join(str(p.resolve()) + "\n" for p in files), encoding="utf-8"
        )
    daten = {
        "quelle": str(quelle.resolve()),
        "native_anzahl": len(native),
        "gui_anzahl": len(gui),
        "kern_sha256": kernkennung(quelle),
        "dateien_sha256": {
            str(p.relative_to(quelle)): hashlib.sha256(p.read_bytes()).hexdigest()
            for p in native + gui
        },
        "start_unix": time.time(),
        "freecadcmd": "/usr/bin/freecadcmd",
        "freecad_gui": "/usr/bin/freecad",
        "profilregel": "pro Datei eigener vorher angelegter Ordner, vor Datenzugriff App-Pfad geprüft",
    }
    (ausgabe / "manifest.json").write_text(json.dumps(daten, indent=2), encoding="utf-8")
    print(f"Inventar: {len(native)} native Tests, {len(gui)} GUI-Szenarien")


def vorgeprueft(datei, quelle, test, log):
    data = json.loads(datei.read_text(encoding="utf-8"))
    entry = data["tests"].get(test.name)
    if entry is None or data["kern_sha256"] != kernkennung(quelle):
        return False
    original = Path(entry["log"])
    if (
        not original.is_file()
        or hashlib.sha256(test.read_bytes()).hexdigest() != entry["test_sha256"]
    ):
        return False
    text = original.read_text(encoding="utf-8", errors="replace")
    if (
        entry.get("log_sha256")
        and hashlib.sha256(original.read_bytes()).hexdigest() != entry["log_sha256"]
    ):
        return False
    if logfehler(text) or not exakt_ok(text, test.name):
        return False
    shutil.copy2(original, log)
    log.with_suffix(".vorbeleg.json").write_text(
        json.dumps(
            {
                "original_log": str(original),
                "log_sha256": hashlib.sha256(original.read_bytes()).hexdigest(),
                "test_sha256": entry["test_sha256"],
                "kern_sha256": data["kern_sha256"],
                "wertung": "Exaktes OK ohne Traceback; identischer eingefrorener Rechen-/UI-Code",
            },
            indent=2,
        ),
        encoding="utf-8",
    )
    return True


def ausfuehren(messung, command):
    """Misst den einzelnen Timeout-/FreeCAD-Prozess samt Kind-RSS, ohne GNU time vorauszusetzen."""
    import resource

    start = time.monotonic()
    result = subprocess.run(command, check=False)
    usage = resource.getrusage(resource.RUSAGE_CHILDREN)
    messung.write_text(
        json.dumps(
            {
                "sekunden": time.monotonic() - start,
                "maxrss_mib": usage.ru_maxrss / 1024,
                "cpu_user_s": usage.ru_utime,
                "cpu_system_s": usage.ru_stime,
                "exit": result.returncode,
                "methode": "Linux RUSAGE_CHILDREN, maximale RSS eines Prozesses, kein Python-only-Wert",
                "kommando": command,
            },
            indent=2,
        ),
        encoding="utf-8",
    )
    return result.returncode if result.returncode >= 0 else 128 - result.returncode


def pruefe_native(log, name, exitcode, profil):
    text = log.read_text(encoding="utf-8", errors="replace")
    marker = "PROFIL_GEPRUEFT " + str(profil.resolve())
    if (
        exitcode != 0
        or logfehler(text)
        or text.count(marker) != 1
        or not (profil / "profilpruefung.json").is_file()
    ):
        return "FEHLER"
    if exakt_ok(text, name):
        return "OK"
    if re.search(r"(?:^|\s)UEBERSPRUNGEN " + re.escape(name) + r":", text):
        return "NICHT_VERFUEGBAR"
    return "FEHLER"


def pruefe_gui(ziel, exitcode, profil, monitor):
    text = (ziel / "freecad.log").read_text(encoding="utf-8", errors="replace")
    try:
        result = (ziel / "ergebnis.txt").read_text(encoding="utf-8")
        screen = json.loads((ziel / "bildschirm.json").read_text(encoding="utf-8"))
        profile = json.loads((profil / "profilpruefung.json").read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return "FEHLER"
    if (
        exitcode != 0
        or logfehler(text)
        or result != "OK"
        or screen["bildschirm"] != monitor
        or not screen["hauptfenster_auf_bildschirm"]
        or not all(w["auf_bildschirm"] for w in screen["sichtbare_fenster"])
        or profile["profil"] != str(profil.resolve())
        or not (ziel / "bildschirm-start.png").is_file()
    ):
        return "FEHLER"
    if ziel.name == "szenario_werkzeugzugang":
        # B-016: Die alte Szenarioassertion prüft nur die Jobliste. Der bereits
        # vorhandene Objektbeleg muss zusätzlich die vollständige Rücknahme zeigen.
        try:
            undo = json.loads((ziel / "uebernahme.json").read_text(encoding="utf-8"))
            vorher, nachher = set(undo["vorher"]), set(undo["nachher"])
        except (OSError, ValueError, KeyError):
            return "FEHLER"
        zusatz = {"kriterium": "Ein Undo stellt den vollständigen ursprünglichen Objektbestand her",
                  "bestanden": vorher == nachher,
                  "uebrig": sorted(nachher - vorher), "fehlend": sorted(vorher - nachher)}
        (ziel / "undo-zusatzpruefung.json").write_text(
            json.dumps(zusatz, ensure_ascii=False, indent=2), encoding="utf-8")
        if vorher != nachher:
            return "FEHLER"
    return "OK"


def zusammenfassung(ausgabe):
    with (ausgabe / "ergebnisse.tsv").open(encoding="utf-8", newline="") as f:
        rows = list(csv.DictReader(f, delimiter="\t"))
    manifest = json.loads((ausgabe / "manifest.json").read_text(encoding="utf-8"))
    data = {
        "native": dict(Counter(r["status"] for r in rows if r["art"] == "native")),
        "gui": dict(Counter(r["status"] for r in rows if r["art"] == "gui")),
        "fehler": [r for r in rows if r["status"] == "FEHLER"],
        "sekunden": sum(float(r["sekunden"]) for r in rows),
        "gesamt_wandzeit_s": time.time() - manifest["start_unix"],
        "beendete_dateien": len(rows),
        "geplante_dateien": manifest["native_anzahl"] + manifest["gui_anzahl"],
        "vollstaendig": len(rows) == manifest["native_anzahl"] + manifest["gui_anzahl"],
        "kern_am_ende_unveraendert": kernkennung(Path(manifest["quelle"]))
        == manifest["kern_sha256"],
        "wochen_build": "Nicht installiert; ausschließlich installierte stabile FreeCAD-Version geprüft",
    }
    (ausgabe / "zusammenfassung.json").write_text(
        json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    lines = [
        f"Dateien: {data['beendete_dateien']}/{data['geplante_dateien']}",
        f"Native: {data['native']}",
        f"GUI: {data['gui']}",
        f"Fehler: {len(data['fehler'])}",
        f"Wandzeit: {data['gesamt_wandzeit_s']:.1f} s",
        data["wochen_build"],
    ]
    lines.extend(f"FEHLER {r['art']} {r['name']}: {r['beleg']}" for r in data["fehler"])
    (ausgabe / "zusammenfassung.txt").write_text("\n".join(lines) + "\n", encoding="utf-8")
    print("\n".join(lines))
    return data["vollstaendig"] and data["kern_am_ende_unveraendert"] and not data["fehler"]


if __name__ == "__main__":
    cmd, *args = sys.argv[1:]
    if cmd == "inventar":
        inventar(Path(args[0]), Path(args[1]))
    elif cmd == "jetzt":
        print(time.monotonic())
    elif cmd == "dauer":
        print(f"{time.monotonic() - float(args[0]):.3f}")
    elif cmd == "vorgeprueft":
        sys.exit(0 if vorgeprueft(*(Path(a) for a in args)) else 1)
    elif cmd == "ausfuehren":
        sys.exit(ausfuehren(Path(args[0]), args[1:]))
    elif cmd == "rss":
        p = Path(args[0]) if args[0] else None
        print(f"{json.loads(p.read_text())['maxrss_mib']:.3f}" if p and p.is_file() else "")
    elif cmd == "pruefe-native":
        print(pruefe_native(Path(args[0]), args[1], int(args[2]), Path(args[3])))
    elif cmd == "pruefe-gui":
        print(pruefe_gui(Path(args[0]), int(args[1]), Path(args[2]), args[3]))
    elif cmd == "zusammenfassung":
        sys.exit(0 if zusammenfassung(Path(args[0])) else 1)
    else:
        raise ValueError(cmd)
