# Gesamtlauf – eigener Prüfharness und Nachweise

```sh
systemd-run --user --scope -q -p MemoryMax=16G -p MemorySwapMax=0 \
  bash /home/manuel/freecad_cam/ergebnisse/abgabe-2026-10-09/gesamtlauf.sh
```

Voraussetzung: fertig qualifizierte, eingefrorene Quelle unter
`/home/manuel/freecad_cam/testen/0.204.0/addon/` als eigenständiger Git-Klon mit
Branch `main`: Die vorhandenen Update-Prüfungen klonen diese Quelle lokal und
benötigen dafür ihre Git-Metadaten. Eine reine Archivkopie reicht nicht. Der Runner führt alle dort
gefundenen nativen Prüfdateien und GUI-Szenarien sequenziell mit dem installierten
FreeCAD aus. Der Wochen-Build ist nicht installiert und wird nicht als geprüft
ausgegeben. Standardzeitlimit: 900 s je native Prüfung, 180 s je GUI-Szenario.
Simultanplanung, native NC-/Folgequalifizierung sowie Gesamt- und Langprüfungen
erhalten 2400 s; die vorhandenen internen Zeit-/Speichergrenzen bleiben unverändert.

Jede ausgeführte Datei erhält ein eigenes vorher angelegtes Profil. Das native
Test-Modul über den öffentlichen Einstieg `Mod/Init.py` bzw. das eigene GUI-Test-Modul prüft `FreeCAD.getUserAppDataDir()` vor
Beispieldatenzugriffen. Der GUI-Lauf verwendet `xcb` und Bildschirm DP-1, auch
für neue eigene modale Dialoge. Besitzerbeziehungen bleiben erhalten. JSON und
Start-/End-Screenshots belegen die tatsächliche Lage. Drei alte Szenarien hatten
einen Screenshot-Helfer für die primäre Anzeige; ausschließlich dieser Helfer
wird im Prüfharness auf DP-1 gerichtet. Die fachlichen Prüfungen bleiben dieselben.

Sieben native Vorbelege dürfen einen identischen Test ersetzen. Voraussetzung:
identischer Rechen-/UI-Code und identische Prüfdatei, exakte `OK <datei>`-Meldung
im benannten Log und keine Python-Ausnahme. Ändert sich der Kern nach Erstellung
von `native_vorbelege.json`, werden alle sieben erneut ausgeführt. Ein Fehler im
neuen Lauf wird gespeichert; anschließend geht es mit der nächsten Datei weiter.
`UEBERSPRUNGEN` zählt nur als ausdrücklich nicht verfügbare native FreeCAD-Funktion.

Die Ausgabe liegt in einem neuen `gesamtlauf-<zeit>/`-Ordner: Originalinventar mit
Dateihashes, einzelne Logs/Screenshots/Profile, `ergebnisse.tsv` mit Status,
Exitcode, Sekunden und Prozess-RSS sowie `zusammenfassung.json`/`.txt`. Prozess-RSS
wird über Linux `RUSAGE_CHILDREN` gemessen (Spitze eines Prozesses, keine Summe
gleichzeitiger Prozesse); die vorhandenen Python-Speicherreferenzen prüfen weiterhin
ihre eigene Messgröße. Die Simultanqualität läuft mit aktivierter Python-Messung;
Referenz-Schreibflags werden vor dem Lauf entfernt. Benutzerprofile werden
weder geändert noch gelöscht. Abgebrochene Läufe bleiben mit ihren Einzelbelegen
erhalten und gelten nicht als vollständiger Abgabenachweis.

## Native Skriptausführung nach den Runnergegenproben

Im ersten Gesamtlauf unter `gesamtstand/` erschienen bei Fehlern doppelte
Skriptausführungen. Die spätere Diagnose zeigte: Einige alte Gegenproben erwarteten
noch Bewegungen außerhalb tatsächlicher Maschinenlimits. Erst nach deren Ausnahme
importierte FreeCAD die gescheiterte Skriptdatei erneut als `__main__`; die
Wiederholung war eine Folge des Fehlers. Sie belegt keinen Produktfehler oder
allgemeinen Fehler von `runpy`.

Eine direkte Übergabe der Originalprüfdatei an FreeCADCmd reicht ebenfalls nicht:
FreeCAD kann sie unter ihrem Modulnamen importieren. Dann wird beispielsweise
`test_ebenen_auslassen.py` mit `if __name__ == "__main__"` überhaupt nicht ausgeführt
und liefert weder OK noch Ausnahme. Das wäre kein bestandener Test.

Der vorbereitete `nativeEntry.py` führt deshalb die unveränderte Originalprüfung
über die öffentliche Python-Funktion `runpy.run_path(..., run_name="__main__")` aus.
Ein unabhängiges, regulär importiertes Test-Modul auditiert Quelle und Profil davor;
der Skripteinstieg verlangt diesen Nachweis. Ein Auditfehler beendet nur unseren
eigenen nativen Prüfprozess mit Exitcode 2. Nicht abgefangene Prüfungsfehler druckt
der Skripteinstieg vollständig und beendet denselben Prozess ebenfalls mit Exitcode 2,
bevor FreeCAD den fehlerhaften Einstieg wiederholen kann. Ein legitimes
`SystemExit(None)` oder `SystemExit(0)` ist erlaubt; die bestehende strenge
OK-/Skip-/Profilwertung entscheidet weiterhin, ob die Prüfung bestanden hat.

Während des laufenden zweiten Gesamtlaufs wurde dessen CLI unverändert gelassen.
Nach Root-Stop verwendet die native Runner-CLI jetzt den neuen Einstieg; Root prüft
ihn vor dem dritten Gesamtlauf mit einer echten Mainguard-Datei und der ursprünglichen
Abfahrgegenprobe. Vorbelege aus dem zweiten Direktlauf werden nicht übernommen;
die sieben vollständig ausgeführten gezielten Vorprüfungen bleiben zulässig.
Die Originalprüfdateien, das Produkt und FreeCAD selbst wurden für diese Harness-
Korrektur nicht verändert.


## Fortsetzung V4b und zusätzliche Undo-Gegenprobe

`gesamtstand-v3` führte alle 106 nativen Dateien aus. 101 bestanden; die
CAM-Maschinendefinition ist in FreeCAD 1.1.4 nicht verfügbar, vier Gegenproben
wurden gezielt berichtigt. Der sichtbare GUI-Läufer hielt ein von Qt bereits
ersetztes QScreen-Objekt und lief dadurch in Zeitlimits. Diese Fehler zählen
nicht als bestandene GUI-Nachweise. Alle alten Ausgaben bleiben archiviert.

`fortsetzung.sh` übernimmt nur die 102 identischen nativen Belege aus V3,
wenn sämtliche Produkt-/Daten-/Hilfedateien und die jeweilige unveränderte
Testdatei bytegleich sind. Alle vier korrigierten nativen Dateien und alle
126 GUI-Szenarien werden neu ausgeführt, im eigenen Profil mit DP-1. Die
Reihenfolge zieht Bahn-/Maschinenfälle vor; die vollständige Liste bleibt
erhalten. `uebernommene-belege.json` dokumentiert die Übernahme.

Die Bildschirmwache speichert nur den Namen und liest QScreen jeweils frisch.
Für `szenario_werkzeugzugang` beobachtet ein öffentlicher DocumentObserver
zusätzlich die Transaktionen; er verändert keine FreeCAD-/Addonfunktion.
Die bereits vom unveränderten Original gespeicherte `uebernahme.json` muss
denselben vollständigen Objektbestand vor Anlegen und nach einem Undo zeigen.
Diese zusätzliche B-016-Gegenprobe ist strenger als die bisherige reine Joblisten-
Assertion. Ihr Urteil liegt in `undo-zusatzpruefung.json`, die unveränderte
Originalwertung weiter in `ergebnis.txt`. Ein übrig gebliebener Rohteilklon gilt
als Befund und verhindert die Gesamtabnahme.

Ein vollständiger Abgabestand benötigt die Gesamtwertung ohne offene Befunde
sowie erfolgreiche reale Starterprüfungen. Neue Produktkorrekturen werden
separat gezielt geprüft und mit den unveränderten Nachweisen nachvollziehbar
zusammengeführt; ein fehlgeschlagener Ausgangslauf wird nicht überschrieben.
