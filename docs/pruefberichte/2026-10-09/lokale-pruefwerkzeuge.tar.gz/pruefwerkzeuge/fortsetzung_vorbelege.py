"""Übernimmt nur identische bestandene Native-Belege; vier Befunde werden erneut geprüft."""
import csv
import hashlib
import json
import sys
from pathlib import Path
from gesamtlauf_hilfe import logfehler, exakt_ok
quelle, ziel = map(Path, sys.argv[1:])
alt = Path(__file__).parent / "gesamtstand-v3"
frozen = Path("/home/manuel/freecad_cam/testen/0.204.0/addon")
manifest = json.loads((alt / "manifest.json").read_text())
# Unveränderter Produktcode und feste Eingabedaten sind eine harte Voraussetzung.
vergleich = []
for name in ("camaddon", "daten", "translations", "beispiele", "help"):
    original = sorted(p.relative_to(frozen) for p in (frozen/name).rglob("*") if p.is_file() and "__pycache__" not in p.parts and p.suffix != ".pyc")
    aktuell = sorted(p.relative_to(quelle) for p in (quelle/name).rglob("*") if p.is_file() and "__pycache__" not in p.parts and p.suffix != ".pyc")
    assert original == aktuell, name
    for rel in original:
        assert (frozen/rel).read_bytes() == (quelle/rel).read_bytes(), str(rel)
        vergleich.append(str(rel))
for name in ("InitGui.py", "package.xml"):
    assert (frozen/name).read_bytes() == (quelle/name).read_bytes(), name
with (alt / "ergebnisse.tsv").open() as f:
    rows=list(csv.DictReader(f, delimiter="\t"))
noch = ["test_schwenken.py", "test_vierachs_plan.py", "test_werkzeuge_aus_cam.py", "test_simultan_planung.py"]
belege=[]
for r in rows:
    if r["art"] != "native" or r["name"] in noch:
        continue
    assert r["status"] in ("OK", "VORGEPRUEFT", "NICHT_VERFUEGBAR"), r
    test=quelle/"tests"/r["name"]
    assert hashlib.sha256(test.read_bytes()).hexdigest() == manifest["dateien_sha256"][str(test.relative_to(quelle))], str(test)
    log=Path(r["beleg"])
    text=log.read_text(errors="replace")
    assert not logfehler(text), str(log)
    if r["status"] != "NICHT_VERFUEGBAR":
        assert exakt_ok(text,r["name"]), str(log)
    belege.append(r)
assert len(belege) == 102, len(belege)
with (ziel/"ergebnisse.tsv").open("w",newline="") as f:
    writer=csv.DictWriter(f,fieldnames=["art","name","status","exit","sekunden","maxrss_mib","beleg"],delimiter="\t")
    writer.writeheader(); writer.writerows(belege)
(ziel/"native-wiederholung.txt").write_text("".join(str(quelle/"tests"/name)+"\n" for name in noch))
(ziel/"uebernommene-belege.json").write_text(json.dumps({"ursprung":str(alt),"produktdateien_unveraendert":vergleich,"native_identisch_uebernommen":belege,"erneut_zu_pruefen":noch,"grund":"Vier Gegenproben angepasst; übriger Produktcode und übrige Testdateien bytegleich; frühere fehlgeschlagene GUI-Proben werden vollständig wiederholt."},ensure_ascii=False,indent=2))
print("102 identische native Belege übernommen, 4 Wiederholungen und 126 GUI-Szenarien offen")
