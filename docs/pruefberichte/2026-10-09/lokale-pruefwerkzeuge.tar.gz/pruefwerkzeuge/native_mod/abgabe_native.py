"""Vor dem direkt gestarteten Originaltest Quelle und eigenes FreeCAD-Profil auditieren."""

import json
import os
import sys
from pathlib import Path

import FreeCAD as App


def pruefen():
    """Wird über Mod/Init.py geladen; startet und importiert niemals die Prüfdatei."""
    profil = Path(os.environ["CAMADDON_ABGABE_ERWARTETES_PROFIL"]).resolve()
    env_profil = Path(os.environ["FREECAD_USER_HOME"]).resolve()
    quelle = Path(os.environ["CAMADDON_ABGABE_QUELLE"]).resolve()
    test = Path(os.environ["CAMADDON_TESTDATEI"]).resolve()
    assert (
        profil.is_dir() and profil == env_profil
    ), "Angelegtes Testprofil stimmt nicht mit Umgebung überein"
    assert (
        Path(App.getUserAppDataDir()).resolve() == profil
    ), "FreeCAD verwendet nicht das eigene Testprofil"
    assert (
        test.is_file() and test.parent == quelle / "tests"
    ), "Prüfdatei gehört nicht zum eingefrorenen Stand"
    sys.path.insert(0, str(quelle))
    import camaddon

    assert Path(camaddon.ADDON_ORDNER).resolve() == quelle, "Falscher Addon-Ladepfad"
    (profil / "profilpruefung.json").write_text(
        json.dumps(
            {
                "profil": str(profil),
                "quelle": str(quelle),
                "addon": camaddon.VERSION,
                "freecad": ".".join(App.Version()[:3]),
                "test": str(test),
                "audit_einstieg": "öffentliches Mod/Init.py vor direkt gestarteter Prüfdatei",
                "audit_modul": __name__,
            },
            indent=2,
        ),
        encoding="utf-8",
    )
    print("PROFIL_GEPRUEFT", str(profil), flush=True)
    if os.environ.get("CAMADDON_NATIVE_DIAGNOSE") == "1":
        import traceback

        def trace(frame, event, arg):
            if frame.f_code.co_filename != str(test):
                return None
            if event == "call" and frame.f_code.co_name == "<module>":
                print("QUELLE_BEGINN", frame.f_globals.get("__name__"), flush=True)
                traceback.print_stack(frame, limit=18)
            if event == "line" and frame.f_lineno == 125:
                op = frame.f_globals.get("op")
                job = frame.f_globals.get("job")
                print("OPDEBUG", op, len(job.Operations.Group[0].Path.Commands), flush=True)
            if event == "exception":
                traceback.print_exception(*arg)
            return trace

        sys.settrace(trace)
