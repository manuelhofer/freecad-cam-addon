# Öffentlicher FreeCAD-App-Mod-Einstieg, auch ohne Oberfläche geladen.
# Ein fehlgeschlagenes Audit muss vor dem ursprünglichen Schreibtest beenden.
import os
import sys
import traceback

try:
    import abgabe_native

    abgabe_native.pruefen()
except BaseException:
    sys.stderr.write("NATIVE_PROFILAUDIT_FEHLER\n" + traceback.format_exc())
    sys.stdout.flush()
    sys.stderr.flush()
    os._exit(2)
