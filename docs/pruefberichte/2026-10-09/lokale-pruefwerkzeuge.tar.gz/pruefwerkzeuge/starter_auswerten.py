"""Strenge Quellen-/Versions-/Profil-/Bildschirmprüfung der tatsächlich gestarteten Starter."""
import json
import sys
from pathlib import Path
base=Path("/home/manuel/freecad_cam/testen/0.204.0")
modus,exitcode=sys.argv[1],int(sys.argv[2])
profil=base/f"profil-{modus}"
assert exitcode==0, (modus,exitcode)
assert not (profil/"startfehler.txt").exists(), (profil/"startfehler.txt").read_text()
x=json.loads((profil/"geladen.json").read_text())
assert x["addon"]=="0.204.0",x
assert x["freecad"]=="1.1.4",x
assert Path(x["addon_ordner"]).resolve()==base/"addon",x
assert Path(x["profil"]).resolve()==profil,x
assert x["bildschirm"]==x["bildschirm_gewuenscht"]=="DP-1" and x["fenster_auf_bildschirm"],x
assert (profil/"start.png").stat().st_size>0
for name in ("vorbereiten.log","freecad.log"):
    s=(profil/name).read_text(errors="replace")
    assert not any(w in s for w in ("Traceback","Exception while processing file:","Segmentation fault","Fatal Python error")),name
print(f"OK Starter {modus}: FreeCAD {x['freecad']}, Addon {x['addon']}, eigenes Profil, DP-1")
