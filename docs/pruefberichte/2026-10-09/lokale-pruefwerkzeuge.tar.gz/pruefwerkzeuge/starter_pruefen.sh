#!/usr/bin/env bash
set -uo pipefail
camaddon_startbasis=/home/manuel/freecad_cam/testen/0.204.0
camaddon_fehler=0
for camaddon_modus in frei schnittbereiche freiform; do
    env CAMADDON_STARTPRUEFUNG=1 timeout --kill-after=15 180 "$camaddon_startbasis/Addon-starten.sh" "$camaddon_modus"
    camaddon_exit=$?
    /usr/bin/python3 /home/manuel/freecad_cam/ergebnisse/abgabe-2026-10-09/starter_auswerten.py "$camaddon_modus" "$camaddon_exit" || camaddon_fehler=1
done
exit "$camaddon_fehler"
