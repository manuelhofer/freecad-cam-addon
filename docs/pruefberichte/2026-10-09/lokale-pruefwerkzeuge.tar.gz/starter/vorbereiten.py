"""Eigene Testprofile vorbereiten; persönliche Werkzeuge ausschließlich kopieren."""

import json
import os
import shutil
import sys
from pathlib import Path

import FreeCAD as App

profil = Path(os.environ["FREECAD_USER_HOME"]).resolve()
quelle = Path(os.environ["CAMADDON_TESTQUELLE"]).resolve()
modus = os.environ["CAMADDON_TESTFALL"]
assert profil.is_dir() and Path(App.getUserAppDataDir()).resolve() == profil
sys.path.insert(0, str(quelle))

import camaddon
from camaddon import sprache

assert Path(camaddon.ADDON_ORDNER).resolve() == quelle
assert modus in ("frei", "schnittbereiche", "freiform")
marker = profil / "eingerichtet.json"
if not marker.exists():
    if modus == "frei":
        persoenlich = Path.home() / ".local/share/FreeCAD/v1-1"
        assert profil != persoenlich.resolve()
        for name in ("CamAddon", "CamAssets"):
            if (persoenlich / name).is_dir():
                shutil.copytree(persoenlich / name, profil / name, dirs_exist_ok=True)
    elif modus == "freiform":
        beispiel = quelle / "beispiele/grob_g550_freiform"
        ziel = profil / "beispiel"
        ziel.mkdir(exist_ok=True)
        shutil.copytree(beispiel / "assets", ziel / "assets", dirs_exist_ok=True)
        for name in (
            "g550_winkelaufnahme.FCStd",
            "freiform_5achs.FCStd",
            "beispiel_werkzeuge.json",
        ):
            shutil.copy2(beispiel / name, ziel / name)
        from Path.Tool.camassets import user_asset_store
        from camaddon import werkzeuge as wz

        user_asset_store.set_dir(ziel / "assets")
        wz.Bibliothek.laden(str(ziel / "beispiel_werkzeuge.json")).speichern()
    sprache.setze_sprache("de")
    prefs = App.ParamGet("User parameter:BaseApp/Preferences/MainWindow")
    prefs.SetString("Theme", "FreeCAD Light")
    prefs.SetString("StyleSheet", "FreeCAD.qss")
    App.saveParameter()
    marker.write_text(
        json.dumps({"modus": modus, "profil": str(profil)}, indent=2), encoding="utf-8"
    )

daten = {
    "profil": str(profil),
    "quelle": str(quelle),
    "addon": camaddon.VERSION,
    "freecad": ".".join(App.Version()[:3]),
    "theme": App.ParamGet("User parameter:BaseApp/Preferences/MainWindow").GetString("Theme"),
    "modus": modus,
}
(profil / "vorbereitet.json").write_text(json.dumps(daten, indent=2), encoding="utf-8")
print("OK Testprofil vorbereitet", flush=True)
