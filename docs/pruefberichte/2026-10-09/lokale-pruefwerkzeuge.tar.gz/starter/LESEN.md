# CAM-Addon 0.204.0 – eigene Teile und geprüfte Beispiele

Der Starter verwendet das installierte `/usr/bin/freecad` und die eingefrorene
Addon-Kopie unter `addon/`. Der aktuelle FreeCAD- und Addon-Stand erscheint im
Fenstertitel und in `profil-<modus>/geladen.json`; dort stehen auch der tatsächliche
Ladepfad, Profilpfad, Bildschirm und Fensterlage. Der vorgesehene Bildschirm ist DP-1.
Diese separate Instanz lädt den neuen lokalen Stand unabhängig vom Addon, das in
deinem bisherigen persönlichen FreeCAD-Profil installiert ist. Aktualisierungen sind
für diese eingefrorene Kopie ausgeschaltet. Die abschließende Gesamtprüfung bleibt
im [Abgabebericht](/home/manuel/freecad_cam/ergebnisse/abgabe-2026-10-09/ABGABEBERICHT.md)
bis zu ihrem Abschluss ausdrücklich offen.

## Eigene Teile und beliebige eingelesene Maschinen

```sh
/home/manuel/freecad_cam/testen/0.204.0/Addon-starten.sh
```

Das freie Profil übernimmt beim ersten Start ausschließlich Kopien deiner
Werkzeugverwaltung und CAM-Assets. Es startet im hellen Theme. Öffne anschließend
dein Teil oder deinen Job. Weise ihm deine Maschine zu; Werkzeugbahnen verwenden
ihre gelesene Kinematik und Anschläge. Der Starter wählt keine Beispielmaschine.
Erreichbare Bereiche bleiben erhalten, unerreichbare Bereiche werden mit Grund
ausgelassen und gelten weiterhin als unbearbeitet.

## Neue sichere Teilstrecken ausprobieren

```sh
/home/manuel/freecad_cam/testen/0.204.0/Teilbereiche-starten.sh
```

Die kleine Gegenprobe öffnet einen einzelnen zusammenhängenden Schnittzug mit
einem unerreichbaren mittleren Abschnitt. Sie verwendet dafür bewusst eine feste
3-Achs-Spindel und wechselnde angeforderte Werkzeugrichtungen. Im Prüffenster
abspielen: die erreichbaren ersten und letzten Schnitte fahren; die Mitte bleibt
im farbigen Rohteilvergleich stehen. Der Hinweis nennt die ausgelassenen Bahnstellen.
Zurückspulen stellt das ganze Rohteil wieder her. „Programm schreiben …“ zeigt
dieselbe Auslassung. Der allgemeine Kern ist zusätzlich mit allen sechs gelesenen
Beispielkinematiken geprüft; diese kleine Gegenprobe stellt nicht deren kompletten
Funktionsumfang dar.

## Bestehendes komplexes Schrupp-/Schlichtbeispiel

```sh
/home/manuel/freecad_cam/testen/0.204.0/Freiform-starten.sh
```

Der vorhandene Freiformjob bearbeitet einen Quader mit Standardfräser Ø 12 und
schlichtet anschließend simultan mit einer angestellten Kugel. Er ist bereits der
gespeicherten G550 mit Winkelaufnahme zugeordnet; das ist eine Beispielmaschine.
Die Strategien selbst verwenden die tatsächlich gewählte Maschine. Dieses Beispiel
zeigt keine allgemeine automatische Aufspannungswahl für beliebige Teile.

Im Prüffenster abspielen und am Ende den farbigen Rohteil-/Sollteil-Vergleich ansehen.
„Bahn“ folgt der aktuellen Operation; „Teil“ blendet das Sollteil um. Zum eigenen
Vergleich das Prüffenster schließen, „3D-Schlichten T4“ auswählen und
„CAM-Addon → 5-Achs-Schlichten vergleichen …“ öffnen. Der Vergleich kann mit
„Schruppen mit vergleichen“ beide Schritte gemeinsam untersuchen. Größere Vergleiche
brauchen mehrere Minuten; der Starter startet sie nicht automatisch.

## Eigene Daten und Prüfbelege

Jeder Modus hat ein separates, vor FreeCAD angelegtes Profil. Beispieldaten werden
ausschließlich dort geschrieben. Im freien Profil spätere Werkzeugänderungen bleiben
erhalten; deine persönliche Bibliothek wird nicht ersetzt. Das Fenster bleibt zum
Ausprobieren offen. Eigenständig bearbeitete Dokumente mit „Speichern unter …“ sichern.

Die native Materialvorschau ist ein Raster; genaue NC-/Materialzulassung und feste
Zeit-/Speicherreferenzen sind in den Prüfdateien des mitgelieferten Stands enthalten.
Der abschließende Prüfbericht liegt im Projekt unter `ergebnisse/`; die Freiformdaten
und ursprünglichen Qualitätsmessungen unter `addon/beispiele/grob_g550_freiform/`.
Die eingefrorene Quellkopie liegt bereits unter `addon/`. Für den tatsächlichen
Startnachweis `profil-<modus>/geladen.json` prüfen: `addon` muss `0.204.0` sein,
`addon_ordner` auf diesen `addon/`-Ordner zeigen, `profil` auf den zugehörigen
Testprofilordner und `bildschirm` auf `DP-1`; `fenster_auf_bildschirm` muss `true`
sein. `start.png` zeigt diese Instanz. Ein fehlender Bildschirm wird ausdrücklich
gemeldet; ein fehlgeschlagener Ladebeleg steht in `startfehler.txt`.
