#!/usr/bin/env bash
set -euo pipefail
camaddon_basis="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
exec "$camaddon_basis/Addon-starten.sh" freiform
