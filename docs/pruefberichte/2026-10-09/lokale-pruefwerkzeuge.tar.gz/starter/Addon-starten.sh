#!/usr/bin/env bash
set -euo pipefail
camaddon_basis="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
camaddon_modus="${1:-frei}"
case "$camaddon_modus" in
    frei|schnittbereiche|freiform) ;;
    *) echo 'Aufruf: Addon-starten.sh [frei|schnittbereiche|freiform]'; exit 2 ;;
esac
export CAMADDON_TESTQUELLE="$camaddon_basis/addon"
export CAMADDON_TESTFALL="$camaddon_modus"
export FREECAD_USER_HOME="$camaddon_basis/profil-$camaddon_modus"
export CAMADDON_OHNE_UPDATE=1 OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1
export CAMADDON_BILDSCHIRM="${CAMADDON_BILDSCHIRM:-DP-1}"
# Xwayland erlaubt das Platzieren auf dem zweiten Bildschirm.
export QT_QPA_PLATFORM=xcb
if [[ ! -f "$CAMADDON_TESTQUELLE/package.xml" ]]; then
    echo 'Die geprüfte Addon-Quellkopie fehlt noch unter addon/. Dieser Starter ist vorbereitet.'
    exit 1
fi
mkdir -p "$FREECAD_USER_HOME/Mod"
ln -sfn "$CAMADDON_TESTQUELLE" "$FREECAD_USER_HOME/Mod/freecad-cam-addon"
# Ein Erfolg eines früheren Starts darf einen neuen Vorbereitungsfehler nicht verdecken.
rm -f "$FREECAD_USER_HOME/vorbereitet.json" "$FREECAD_USER_HOME/geladen.json" \
    "$FREECAD_USER_HOME/startfehler.txt" "$FREECAD_USER_HOME/start.png"
systemd-run --user --scope -q -p MemoryMax=16G -p MemorySwapMax=0 \
    /usr/bin/freecadcmd -u "$FREECAD_USER_HOME/user.cfg" -s "$FREECAD_USER_HOME/system.cfg" \
    "$camaddon_basis/vorbereiten.py" > "$FREECAD_USER_HOME/vorbereiten.log" 2>&1
test -f "$FREECAD_USER_HOME/vorbereitet.json" || { cat "$FREECAD_USER_HOME/vorbereiten.log"; exit 1; }
exec systemd-run --user --scope -q -p MemoryMax=16G -p MemorySwapMax=0 \
    /usr/bin/freecad -u "$FREECAD_USER_HOME/user.cfg" -s "$FREECAD_USER_HOME/system.cfg" \
    "$camaddon_basis/starten.FCMacro" > "$FREECAD_USER_HOME/freecad.log" 2>&1
